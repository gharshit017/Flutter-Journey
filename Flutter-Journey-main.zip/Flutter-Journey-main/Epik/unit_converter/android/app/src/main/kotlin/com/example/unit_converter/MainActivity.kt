package com.example.unit_converter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

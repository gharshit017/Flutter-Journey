package com.example.project_assignment_21_05_2022

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

package com.example.list_and_chart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

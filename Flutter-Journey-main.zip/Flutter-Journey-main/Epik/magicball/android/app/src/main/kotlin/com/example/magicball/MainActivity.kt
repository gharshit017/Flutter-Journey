package com.example.magicball

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
